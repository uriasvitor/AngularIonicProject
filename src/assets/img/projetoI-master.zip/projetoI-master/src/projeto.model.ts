export class projetoModel{
    titulo:string;
    id?:any;
    endereco?:string;
    numero?:number;
    complemento:string;
    formaPagamento:string;
    status:boolean;
    produto_status:string;
    valor:string;
    pedido:string;
    ativo:boolean;
    orc:string;
    data:string;
    situacao:string;
    imagens:Array<object>;
}